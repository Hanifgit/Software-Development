﻿namespace Bookkeeping_Software
{
    partial class Your_Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Your_Profile));
            this.panel1 = new System.Windows.Forms.Panel();
            this.PathImage = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtRoles = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TxtOldPassword = new System.Windows.Forms.TextBox();
            this.CP = new System.Windows.Forms.Label();
            this.TxtConfirmNewPassword = new System.Windows.Forms.TextBox();
            this.NP = new System.Windows.Forms.Label();
            this.TxtNewPassword = new System.Windows.Forms.TextBox();
            this.T = new System.Windows.Forms.Label();
            this.TxtUserName = new System.Windows.Forms.TextBox();
            this.lblUpdate = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.BtnPhoto = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.UpdateProfil = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.UplodePicture = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Other = new System.Windows.Forms.RadioButton();
            this.Female = new System.Windows.Forms.RadioButton();
            this.Male = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtBirthDay = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtPhone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtEname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtLName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtFname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtCompany = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UplodePicture)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.LightGreen;
            this.panel1.Controls.Add(this.PathImage);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.txtRoles);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.TxtOldPassword);
            this.panel1.Controls.Add(this.CP);
            this.panel1.Controls.Add(this.TxtConfirmNewPassword);
            this.panel1.Controls.Add(this.NP);
            this.panel1.Controls.Add(this.TxtNewPassword);
            this.panel1.Controls.Add(this.T);
            this.panel1.Controls.Add(this.TxtUserName);
            this.panel1.Controls.Add(this.lblUpdate);
            this.panel1.Controls.Add(this.Delete);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.BtnPhoto);
            this.panel1.Controls.Add(this.Button2);
            this.panel1.Controls.Add(this.UpdateProfil);
            this.panel1.Controls.Add(this.Button1);
            this.panel1.Controls.Add(this.UplodePicture);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.Other);
            this.panel1.Controls.Add(this.Female);
            this.panel1.Controls.Add(this.Male);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.TxtBirthDay);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.TxtPhone);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.TxtEname);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.TxtLName);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.TxtFname);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.TxtCompany);
            this.panel1.Location = new System.Drawing.Point(57, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(678, 615);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // PathImage
            // 
            this.PathImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PathImage.ForeColor = System.Drawing.Color.Black;
            this.PathImage.Location = new System.Drawing.Point(218, 10);
            this.PathImage.Multiline = true;
            this.PathImage.Name = "PathImage";
            this.PathImage.Size = new System.Drawing.Size(180, 29);
            this.PathImage.TabIndex = 46;
            this.PathImage.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(151, 348);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 44;
            this.label10.Text = "Roles :";
            // 
            // txtRoles
            // 
            this.txtRoles.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoles.ForeColor = System.Drawing.Color.Black;
            this.txtRoles.Location = new System.Drawing.Point(215, 339);
            this.txtRoles.Multiline = true;
            this.txtRoles.Name = "txtRoles";
            this.txtRoles.Size = new System.Drawing.Size(354, 29);
            this.txtRoles.TabIndex = 43;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(104, 416);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 13);
            this.label9.TabIndex = 42;
            this.label9.Text = "Old Password :";
            // 
            // TxtOldPassword
            // 
            this.TxtOldPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtOldPassword.ForeColor = System.Drawing.Color.Black;
            this.TxtOldPassword.Location = new System.Drawing.Point(215, 407);
            this.TxtOldPassword.Multiline = true;
            this.TxtOldPassword.Name = "TxtOldPassword";
            this.TxtOldPassword.Size = new System.Drawing.Size(354, 29);
            this.TxtOldPassword.TabIndex = 41;
            this.TxtOldPassword.UseSystemPasswordChar = true;
            // 
            // CP
            // 
            this.CP.AutoSize = true;
            this.CP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CP.ForeColor = System.Drawing.Color.White;
            this.CP.Location = new System.Drawing.Point(56, 482);
            this.CP.Name = "CP";
            this.CP.Size = new System.Drawing.Size(141, 13);
            this.CP.TabIndex = 40;
            this.CP.Text = "Confirm new password :";
            // 
            // TxtConfirmNewPassword
            // 
            this.TxtConfirmNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtConfirmNewPassword.ForeColor = System.Drawing.Color.Black;
            this.TxtConfirmNewPassword.Location = new System.Drawing.Point(215, 474);
            this.TxtConfirmNewPassword.Multiline = true;
            this.TxtConfirmNewPassword.Name = "TxtConfirmNewPassword";
            this.TxtConfirmNewPassword.Size = new System.Drawing.Size(354, 29);
            this.TxtConfirmNewPassword.TabIndex = 39;
            this.TxtConfirmNewPassword.UseSystemPasswordChar = true;
            // 
            // NP
            // 
            this.NP.AutoSize = true;
            this.NP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NP.ForeColor = System.Drawing.Color.White;
            this.NP.Location = new System.Drawing.Point(102, 449);
            this.NP.Name = "NP";
            this.NP.Size = new System.Drawing.Size(93, 13);
            this.NP.TabIndex = 38;
            this.NP.Text = "New password:";
            // 
            // TxtNewPassword
            // 
            this.TxtNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNewPassword.ForeColor = System.Drawing.Color.Black;
            this.TxtNewPassword.Location = new System.Drawing.Point(215, 440);
            this.TxtNewPassword.Multiline = true;
            this.TxtNewPassword.Name = "TxtNewPassword";
            this.TxtNewPassword.Size = new System.Drawing.Size(354, 29);
            this.TxtNewPassword.TabIndex = 37;
            this.TxtNewPassword.UseSystemPasswordChar = true;
            // 
            // T
            // 
            this.T.AutoSize = true;
            this.T.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T.ForeColor = System.Drawing.Color.White;
            this.T.Location = new System.Drawing.Point(121, 217);
            this.T.Name = "T";
            this.T.Size = new System.Drawing.Size(77, 13);
            this.T.TabIndex = 36;
            this.T.Text = "User Name :";
            // 
            // TxtUserName
            // 
            this.TxtUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtUserName.ForeColor = System.Drawing.Color.Black;
            this.TxtUserName.Location = new System.Drawing.Point(215, 209);
            this.TxtUserName.Multiline = true;
            this.TxtUserName.Name = "TxtUserName";
            this.TxtUserName.Size = new System.Drawing.Size(354, 29);
            this.TxtUserName.TabIndex = 35;
            // 
            // lblUpdate
            // 
            this.lblUpdate.AutoSize = true;
            this.lblUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblUpdate.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblUpdate.Location = new System.Drawing.Point(328, 591);
            this.lblUpdate.Name = "lblUpdate";
            this.lblUpdate.Size = new System.Drawing.Size(42, 13);
            this.lblUpdate.TabIndex = 34;
            this.lblUpdate.Text = "Update";
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.Delete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.Delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.ForeColor = System.Drawing.Color.White;
            this.Delete.Location = new System.Drawing.Point(495, 540);
            this.Delete.Margin = new System.Windows.Forms.Padding(0);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(74, 36);
            this.Delete.TabIndex = 33;
            this.Delete.Text = "Delate Account?";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.lblName.Location = new System.Drawing.Point(214, 150);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(84, 19);
            this.lblName.TabIndex = 32;
            this.lblName.Text = "UserName";
            // 
            // BtnPhoto
            // 
            this.BtnPhoto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.BtnPhoto.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.BtnPhoto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.BtnPhoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPhoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPhoto.ForeColor = System.Drawing.Color.White;
            this.BtnPhoto.Location = new System.Drawing.Point(73, 125);
            this.BtnPhoto.Margin = new System.Windows.Forms.Padding(0);
            this.BtnPhoto.Name = "BtnPhoto";
            this.BtnPhoto.Size = new System.Drawing.Size(78, 36);
            this.BtnPhoto.TabIndex = 31;
            this.BtnPhoto.Text = "Change photo";
            this.BtnPhoto.UseVisualStyleBackColor = false;
            this.BtnPhoto.Click += new System.EventHandler(this.btnPhoto_Click);
            // 
            // Button2
            // 
            this.Button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button2.ForeColor = System.Drawing.Color.White;
            this.Button2.Location = new System.Drawing.Point(404, 540);
            this.Button2.Margin = new System.Windows.Forms.Padding(0);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(74, 36);
            this.Button2.TabIndex = 30;
            this.Button2.Text = "Clear";
            this.Button2.UseVisualStyleBackColor = false;
            this.Button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // UpdateProfil
            // 
            this.UpdateProfil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.UpdateProfil.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.UpdateProfil.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.UpdateProfil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateProfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateProfil.ForeColor = System.Drawing.Color.White;
            this.UpdateProfil.Location = new System.Drawing.Point(215, 540);
            this.UpdateProfil.Margin = new System.Windows.Forms.Padding(0);
            this.UpdateProfil.Name = "UpdateProfil";
            this.UpdateProfil.Size = new System.Drawing.Size(74, 36);
            this.UpdateProfil.TabIndex = 29;
            this.UpdateProfil.Text = "Update";
            this.UpdateProfil.UseVisualStyleBackColor = false;
            this.UpdateProfil.Click += new System.EventHandler(this.Sign_Click);
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(162)))), ((int)(((byte)(82)))));
            this.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.ForeColor = System.Drawing.Color.White;
            this.Button1.Location = new System.Drawing.Point(310, 540);
            this.Button1.Margin = new System.Windows.Forms.Padding(0);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(74, 36);
            this.Button1.TabIndex = 28;
            this.Button1.Text = "Cancel";
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // UplodePicture
            // 
            this.UplodePicture.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.UplodePicture.Image = ((System.Drawing.Image)(resources.GetObject("UplodePicture.Image")));
            this.UplodePicture.Location = new System.Drawing.Point(36, 10);
            this.UplodePicture.Name = "UplodePicture";
            this.UplodePicture.Size = new System.Drawing.Size(160, 110);
            this.UplodePicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.UplodePicture.TabIndex = 26;
            this.UplodePicture.TabStop = false;
            this.UplodePicture.Click += new System.EventHandler(this.UplodePicture_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(287, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(199, 20);
            this.label8.TabIndex = 25;
            this.label8.Text = "Complete Your Account";
            // 
            // Other
            // 
            this.Other.AutoSize = true;
            this.Other.ForeColor = System.Drawing.Color.White;
            this.Other.Location = new System.Drawing.Point(336, 511);
            this.Other.Name = "Other";
            this.Other.Size = new System.Drawing.Size(51, 17);
            this.Other.TabIndex = 24;
            this.Other.TabStop = true;
            this.Other.Text = "Other";
            this.Other.UseVisualStyleBackColor = true;
            // 
            // Female
            // 
            this.Female.AutoSize = true;
            this.Female.ForeColor = System.Drawing.Color.White;
            this.Female.Location = new System.Drawing.Point(271, 510);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(59, 17);
            this.Female.TabIndex = 23;
            this.Female.TabStop = true;
            this.Female.Text = "Female";
            this.Female.UseVisualStyleBackColor = true;
            // 
            // Male
            // 
            this.Male.AutoSize = true;
            this.Male.ForeColor = System.Drawing.Color.White;
            this.Male.Location = new System.Drawing.Point(215, 510);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(48, 17);
            this.Male.TabIndex = 22;
            this.Male.TabStop = true;
            this.Male.Text = "Male";
            this.Male.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(141, 512);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Gender :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(419, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Birth Day :";
            this.label7.Visible = false;
            // 
            // TxtBirthDay
            // 
            this.TxtBirthDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBirthDay.ForeColor = System.Drawing.Color.Black;
            this.TxtBirthDay.Location = new System.Drawing.Point(504, 41);
            this.TxtBirthDay.Multiline = true;
            this.TxtBirthDay.Name = "TxtBirthDay";
            this.TxtBirthDay.Size = new System.Drawing.Size(134, 29);
            this.TxtBirthDay.TabIndex = 19;
            this.TxtBirthDay.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(147, 381);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Phone :";
            // 
            // TxtPhone
            // 
            this.TxtPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPhone.ForeColor = System.Drawing.Color.Black;
            this.TxtPhone.Location = new System.Drawing.Point(215, 373);
            this.TxtPhone.Multiline = true;
            this.TxtPhone.Name = "TxtPhone";
            this.TxtPhone.Size = new System.Drawing.Size(354, 29);
            this.TxtPhone.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(152, 315);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Email :";
            // 
            // TxtEname
            // 
            this.TxtEname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEname.ForeColor = System.Drawing.Color.Black;
            this.TxtEname.Location = new System.Drawing.Point(215, 306);
            this.TxtEname.Multiline = true;
            this.TxtEname.Name = "TxtEname";
            this.TxtEname.ReadOnly = true;
            this.TxtEname.Size = new System.Drawing.Size(354, 29);
            this.TxtEname.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(122, 283);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Last Name :";
            // 
            // TxtLName
            // 
            this.TxtLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtLName.ForeColor = System.Drawing.Color.Black;
            this.TxtLName.Location = new System.Drawing.Point(215, 274);
            this.TxtLName.Multiline = true;
            this.TxtLName.Name = "TxtLName";
            this.TxtLName.Size = new System.Drawing.Size(354, 29);
            this.TxtLName.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(122, 249);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "First Name :";
            // 
            // TxtFname
            // 
            this.TxtFname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFname.ForeColor = System.Drawing.Color.Black;
            this.TxtFname.Location = new System.Drawing.Point(215, 241);
            this.TxtFname.Multiline = true;
            this.TxtFname.Name = "TxtFname";
            this.TxtFname.Size = new System.Drawing.Size(354, 29);
            this.TxtFname.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(95, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Company Name :";
            // 
            // TxtCompany
            // 
            this.TxtCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCompany.ForeColor = System.Drawing.Color.Black;
            this.TxtCompany.Location = new System.Drawing.Point(215, 177);
            this.TxtCompany.Multiline = true;
            this.TxtCompany.Name = "TxtCompany";
            this.TxtCompany.Size = new System.Drawing.Size(354, 29);
            this.TxtCompany.TabIndex = 9;
            this.TxtCompany.TextChanged += new System.EventHandler(this.txtCompany_TextChanged);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.button5.Location = new System.Drawing.Point(768, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(28, 36);
            this.button5.TabIndex = 52;
            this.button5.Text = "X";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.button4.Location = new System.Drawing.Point(735, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(29, 36);
            this.button4.TabIndex = 51;
            this.button4.Text = "_";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(87)))), ((int)(((byte)(139)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Webdings", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.button3.Location = new System.Drawing.Point(703, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(28, 36);
            this.button3.TabIndex = 50;
            this.button3.Text = "1";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Your_Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(114)))));
            this.ClientSize = new System.Drawing.Size(800, 700);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Your_Profile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Your_Profile";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Your_Profile_FormClosed);
            this.Load += new System.EventHandler(this.Your_Profile_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Your_Profile_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Your_Profile_MouseMove);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UplodePicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TxtCompany;
        private System.Windows.Forms.RadioButton Other;
        private System.Windows.Forms.RadioButton Female;
        private System.Windows.Forms.RadioButton Male;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TxtBirthDay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TxtPhone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtEname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtLName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtFname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox UplodePicture;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button UpdateProfil;
        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.Button Button2;
        private System.Windows.Forms.Button BtnPhoto;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Label lblUpdate;
        private System.Windows.Forms.Label CP;
        private System.Windows.Forms.TextBox TxtConfirmNewPassword;
        private System.Windows.Forms.Label NP;
        private System.Windows.Forms.TextBox TxtNewPassword;
        private System.Windows.Forms.Label T;
        private System.Windows.Forms.TextBox TxtUserName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TxtOldPassword;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtRoles;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox PathImage;
    }
}